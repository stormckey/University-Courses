#include "cachelab.h"


int main(int argc,char* argv[])
{
    printSummary(0, 0, 0);
    return 0;
}
